// See the following on using objects as key/value dictionaries
// https://stackoverflow.com/questions/1208222/how-to-do-associative-array-hashing-in-javascript
var words = {};
var users = {};

/* Observer class */
function Observer(){
    this.fn = null;
    this.val = null;
    this.setObserver = function(fn,val){
	this.fn = fn ;
	this.val = val;
    };
    this.getObserver = function(){
	return this;
    };
    this.fire = function(){
	this.fn(this.val);
    };
}
/* stack class */
function Stack() {
    this.data = [];
    this.observers = [];
    this.size = 0;
    this.push = function(element){
	this.data[this.size++] = element;
	this.fire();
    };
    this.pop = function(){
	this.size--;
	var val = this.data.pop();
	this.fire();
	return val;
    };
    this.clear = function(){
	this.top = 0;
	this.fire();
    };
    
    this.peek = function(){
	return this.data[this.size-1];
    };
    this.subscribe = function(observer){
	this.observers.push(observer);
    };
    this.unsubscribe = function(fn){
	this.observers = this.observers.filter(function(item) {
	    if (item.fn !== fn) 
		return item;
	});
    };
    this.fire = function(){
	this.observers.forEach(function(observer){
	    observer.fire();
	});
    };
    this.renderStack = function(fn){
	this.data.slice().reverse().forEach(function(item){
	    var observer = new Observer();
	    observer.setObserver(fn,item);
	    observer.fire();
	});
    };
}

/* ObservableStack class */
function ObservableStack(){
	this.registerObserver = function(fn){
		var observer = new Observer();
		observer.setObserver(fn,this);
		this.subscribe(observer);
	};
}
ObservableStack.prototype  = new Stack();

/** 
 * When the length of stack is larger than 0, then pop
 */
function emptyStack(stack) {
    while (stack.size > 0){
	stack.pop();
    }
}

/**
 * Print a string out to the terminal, and update its scroll to the
 * bottom of the screen. You should call this so the screen is
 * properly scrolled.
 * @param {Terminal} terminal - The `terminal` object to write to
 * @param {string}   msg      - The message to print to the terminal
 */
function print(terminal, msg) {
    terminal.print(msg);
    $("#terminal").scrollTop($('#terminal')[0].scrollHeight + 40);
}

/** 
 * Sync up the HTML with the stack in memory
 * @param {Array[Number]} The stack to render
 */
function renderStack(stack) {
    $("#thestack").empty();
    stack.data.slice().reverse().forEach(function(element) {
        $("#thestack").append("<tr><td>" + element + "</td></tr>");
    });
};

function findIf(str){
    return str === "if";
}


function defRun(stack, arr){
    var ifposition = arr.indexOf("if");
    var elseposition = arr.indexOf("else");
    var endifposition = arr.indexOf("endif");
    var beforeif = arr.slice(0, ifposition);
    var ifelse = arr.slice(ifposition+1, elseposition);
    var elseendif = arr.slice(elseposition+1, endifposition);
    var afterendif = arr.slice(endifposition+1);
    if(ifposition != -1){
	beforeif.forEach(function(i){
	    if (!(isNaN(Number(i)))) {
		stack.push(Number(i));
	    } else if (i in words) {
		var func = words[i];
		func(stack);
	    } else if (i in users){
		var func = users[i];
		defRun(stack, func);
	    }
	})
	var condition = stack.pop();
	if (condition === 0){
	    defRun(stack, elseendif);
	    defRun(stack, afterendif);
	}else{
	    defRun(stack, ifelse);
	    defRun(stack, afterendif);
	}
    }else{
	arr.forEach(function(i){
	    if (!(isNaN(Number(i)))) {
		stack.push(Number(i));
	    } else if (i in words) {
		var func = words[i];
		func(stack);
	    } else if (i in users){
		var func = users[i];
		defRun(stack, func);
	    }
	})
    }
    // renderStack(stack);
}

function renderButtons(stack) {
    $("#buttons").empty();
    for (var key in users) {
	var $new_button = $('<input/>').attr({ type: 'button', name:'btn_'+key, value:key});
	$new_button.click(function(){
	    defRun(stack, users[key]);
	});
	$("#buttons").append($new_button);	
    }
};

/** 
 * Process a user input, update the stack accordingly, write a
 * response out to some terminal.
 * @param {Array[Number]} stack - The stack to work on
 * @param {string} input - The string the user typed
 * @param {Terminal} terminal - The terminal object
 */

function add(stack){
    var first = stack.pop();
    var second = stack.pop();
    stack.push(first+second);
    
}

function subtract(stack){
    var first = stack.pop();
    var second = stack.pop();
    stack.push(second-first);
}

function multiplication(stack){
    var first = stack.pop();
    var second = stack.pop();
    stack.push(second*first);
}

function division(stack){
    var first = stack.pop();
    var second = stack.pop();
    stack.push(Math.floor(second/first));
}

function swap(stack){
    var first = stack.pop();
    var second = stack.pop();
    stack.push(first);
    stack.push(second);
}

function nip(stack){
    var first = stack.pop();
    var second = stack.pop();
    stack.push(first);
}

function over(stack){
    var first = stack.pop();
    var second = stack.pop();
    stack.push(second);
    stack.push(first);
    stack.push(second);
}

function lessThan(stack){
    var first = stack.pop();
    var second = stack.pop();
    if (second < first){
	stack.push(-1);
    }else {
	stack.push(0);
    }    
}

function equalTo(stack){
    var first = stack.pop();
    var second = stack.pop();
    if (second === first){
	stack.push(-1);
    }else {
	stack.push(0);
    }
}

function largerThan(stack){
    var first = stack.pop();
    var second = stack.pop();
    if (second > first){
	stack.push(-1);
    }else {
	stack.push(0);
    }
}

words={"+":add,"-":subtract,"*":multiplication,"/":division,"swap":swap,
       "nip":nip,"over":over,"<":lessThan,"=":equalTo, ">":largerThan};

function userDefined(stack, arr){
    var ifposition = arr.indexOf("if");
    var elseposition = arr.indexOf("else");
    var endifposition = arr.indexOf("endif");
    var beforeif = arr.slice(0, ifposition);
    var ifelse = arr.slice(ifposition+1, elseposition);
    var elseendif = arr.slice(elseposition+1, endifposition);
    var afterendif = arr.slice(endifposition+1);
    if(ifposition != -1){
	beforeif.forEach(function(i){
	    if (!(isNaN(Number(i)))) {
		stack.push(Number(i));
	    } else if (i in words) {
		var func = words[i];
		func(stack);
	    } else if (i in users){
		var func = users[i];
		userDefined(stack, func);
	    }
	})
	var condition = stack.pop();
	if (condition === 0){
	    userDefined(stack, elseendif);
	    userDefined(stack, afterendif);
	}else{
	    userDefined(stack, ifelse);
	    userDefined(stack, afterendif);
	}
    }
    else{
	arr.forEach(function(i){
	    if (!(isNaN(Number(i)))) {
		stack.push(Number(i));
	    } else if (i in words) {
		var func = words[i];
		func(stack);
	    } else if (i in users){
		var func = users[i];
		userDefined(stack, func);
	    }
	})
    }
    // renderStack(stack);
}

function process(stack, input, terminal) {
    var inputArray = input.trim().split(/ +/);
    if (inputArray === []){
	return stack;
    }
    else if (inputArray[0]===":"){
    	var name = inputArray[1];
    	var def = inputArray.slice(2,-1);
    	if (name in words){
    	    print(terminal, ":-( Has been defined as a built-in function");
    	} else{
    	    def.forEach(function(i){
        	if ((isNaN(Number(i)) && !(i in words) && !(i in users)  && !(i === "if")  && !(i === "else")  && !(i === "endif"))){
        	    print(terminal, ":-( Unrecognized input");
        	}
    	    })
	}
    	users[name] = def;
    	var $something= $('<input/>').attr({ type: 'button', name:name, value:def});
    	$("#var").append($something);
    }
    else {
    	inputArray.forEach(function(i){
    	    if (!(isNaN(Number(i)))) {
        	print(terminal,"pushing " + Number(i));
        	stack.push(Number(i));   
    	    } 
	    else {
        	if (i in words){
        	    var func = words[i];
        	    func(stack);
        	}
                else if (i in users){
		    var func = users[i];
		    userDefined(stack, func);
        	}
                else {	
		    print(terminal, ":-( Unrecognized input");
        	}
    	    }
    	})
    }
    //renderStack(stack);
    renderButtons(stack);
};

/*
  function drawCircle(){
  //????Canvas????(????)
  var canvas = $("#myCanvas");
  //????????????????????????????Canvas??????????????????????html5??????????????????????
  if(canvas.getContext){  
  //??????????CanvasRenderingContext2D????(????)
  var ctx = canvas.getContext("2d");  
  
  //????????????????????
  ctx.beginPath();
  //????????????????????
  ctx.strokeStyle = "blue";
  var circle = {
  x : 100,    //??????x????????
  y : 100,    //??????y????????
  r : 50      //????????
  };
  //??????????(100,100)??????????????50px????????????????????????
  ctx.arc(circle.x, circle.y, circle.r, 0, Math.PI / 2, false);    
  //??????????????????????
  ctx.stroke();
  }
  }
*/

function runRepl(terminal, stack) {
    terminal.input("Type a forth command:", function(line) {
        print(terminal, "User typed in: " + line);
        process(stack, line, terminal);
        runRepl(terminal, stack);
    });
};

// Whenever the page is finished loading, call this function. 
// See: https://learn.jquery.com/using-jquery-core/document-ready
$(document).ready(function() {
    var terminal = new Terminal();
    terminal.setHeight("400px");
    terminal.blinkingCursor(true);
    
    // Find the "terminal" object and change it to add the HTML that
    // represents the terminal to the end of it.
    $("#terminal").append(terminal.html);
    
    var stack = new ObservableStack();
    stack.registerObserver(function(v){print(terminal, "ObservableStack stack changed! ");});
    stack.registerObserver(function(v){renderStack(stack);});
    
    $("#reset").click(function(){
	emptyStack(stack);
	//renderStack(stack);
    });
    //drawCircle();
    print(terminal, "Welcome to HaverForth! v0.1");
    print(terminal, "As you type, the stack (on the right) will be kept in sync");
    runRepl(terminal, stack);
});



